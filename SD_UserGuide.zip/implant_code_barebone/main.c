/*
 * main.c
 *
 * RF430FRL152H Default Example Project
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include <rf430frl152h.h>
#include "patch.h"
#include "types.h"

#define MASTER_SLAVE_SELECT         BIT7
#define PORT_I2C_OUT    P1OUT
#define PORT_I2C_DIR    P1DIR
#define PORT_I2C_SEL0    P1SEL0
#define PORT_I2C_SEL1    P1SEL1
#define SDA    BIT0
#define SCL BIT1


#define GCTRL_REG (*((volatile u08_t*)0xF868))
#define SENSORCTRL_REG (*((volatile u08_t*)0xF86A))
#define NUM_PASSES_REG (*((volatile u08_t*)0xF86C))
#define STATUS_REG (*((volatile u08_t*)0xF869))
#define SAMPLED_DATA (*((volatile u16_t*)0xF8B0))
#define MEM_SIZE_REG (*((volatile u16_t*)0xF8A8))

/**************************************************************************************************************************************************
*   Code Space
***************************************************************************************************************************************************
*
*  Please check the lnk_rf430frl152h_ROM_Init.cmd file to customize how much code space is used for logging("FRAM")
*  or for code ("FRAM_CODE").  
*  Also for each new function, please use the following line before the function, to put the code in the correct section:
*  #pragma CODE_SECTION (MyFunction, ".fram_driver_code") //also change MyFunction to the function name
*
**************************************************************************************************************************************************/

//*****************************FUNCTION PROTOTYPES********************************/
void userCustomCommand();
//********************************************************************************/
//see .cmd file for details - all new firmware must go into fram_driver_code memory section space

/**************************************************************************************************************************************************
*  userCustomCommand
***************************************************************************************************************************************************
*
* Brief : This function is called by the RF stack whenever a custom command by its ID number is transmitted
*
* Param[in] :   None
*
* Param[out]:   None
*
* Return        None
*
* This is an example only, and the user if free to modify as needed.
*
* Operation: Example with TRF7970AEVM
* Use Test tab to send following sequence: 18 02 AA 07 10 10
* 18 - TRF7970AEVM Host command (omit for other readers - not sent out over RF)
* 02 - High speed mode selection (start of actuall RF packet)
* AA - The actual custom command
* 07 - TI Manufacturer ID (need by this IC)
* 01 - Set Error LED to on  (0x00 to be off)
**************************************************************************************************************************************************/
#pragma CODE_SECTION (userCustomCommand, ".fram_driver_code") //see .cmd file for details - all new firmware must go into fram_driver_code memory section space
void userCustomCommand()
{
    u08_t control;                    //for the command received

    if( RF13MFIFOFL_L == CRC_LENGTH_IN_BUFFER + DATA_IN_LENGTH){    //DATA_IN_LENGTH is bytes expected, defined in patch.h
        control = RF13MRXF_L;        //read from receive FIFO
        RF13MTXF = control;
        return
    }
    else
        RF13MTXF = 0xFFFF;            // an error response
}

extern __interrupt void Reset_ISR(void);

//#pragma CODE_SECTION(RFPMM_ISR, ".fram_driver_code")   //comment this line for using ROM's RFPMM ISR, uncomment next one
#pragma CODE_SECTION(RFPMM_ISR, ".rfpmm_rom_isr") //comment this line for creating a custom RFPMM ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = RFPMM_VECTOR
__interrupt void RFPMM_ISR(void)
{
}

//#pragma CODE_SECTION(PORT1_ISR, ".fram_driver_code")   //comment this line for using ROM's PORT1 ISR, uncomment next one
#pragma CODE_SECTION(PORT1_ISR, ".port1_rom_isr") //comment this line for creating a custom PORT1 ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
}

#pragma CODE_SECTION(SD_ADC_ISR, ".fram_driver_code")   //comment this line for using ROM's SD14_ADC ISR, uncomment next one
//#pragma CODE_SECTION(SD_ADC_ISR, ".sd_14_rom_isr") //comment this line for creating a custom SD14_ADC ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = SD_ADC_VECTOR
__interrupt void SD_ADC_ISR(void)
{
}

//#pragma CODE_SECTION(USCI_B0_ISR, ".fram_driver_code")   //comment this line for using ROM's USCI_B0 ISR, uncomment next one
#pragma CODE_SECTION(USCI_B0_ISR, ".usci_b0_rom_isr") //comment this line for creating a custom USCI_B0 ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = USCI_B0_VECTOR
__interrupt void USCI_B0_ISR(void)
{
}

//#pragma CODE_SECTION(RF13M_ISR, ".fram_driver_code")   //comment this line for using ROM's RF13M ISR, uncomment next one
#pragma CODE_SECTION(RF13M_ISR, ".rf13m_rom_isr") //comment this line for creating a custom RF13M ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = RF13M_VECTOR
__interrupt void RF13M_ISR(void)
{
}

//#pragma CODE_SECTION(WDT_ISR, ".fram_driver_code")   //comment this line for using ROM's WDT ISR, uncomment next one
#pragma CODE_SECTION(WDT_ISR, ".wdt_rom_isr") //comment this line for creating a custom WDT ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = WDT_VECTOR
__interrupt void WDT_ISR(void)
{
}

//#pragma CODE_SECTION(TimerA1_ISR, ".fram_driver_code")   //comment this line for using ROM's Timer_A1 ISR, uncomment next one
#pragma CODE_SECTION(TimerA1_ISR, ".timer_a1_rom_isr") //comment this line for creating a custom WDT ISR TimerA1 that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = TIMER0_A1_VECTOR
__interrupt void TimerA1_ISR(void)
{
}

//#pragma CODE_SECTION(TimerA0_ISR, ".fram_driver_code")   //comment this line for using ROM's Timer_A0 ISR, uncomment next one
#pragma CODE_SECTION(TimerA0_ISR, ".timer_a0_rom_isr") //comment this line for creating a custom WDT ISR Timer_A0 that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = TIMER0_A0_VECTOR
__interrupt void TimerA0_ISR(void)
{
}

//#pragma CODE_SECTION(UNMI_ISR, ".fram_driver_code")   //comment this line for using ROM's UNMI ISR, uncomment next one
#pragma CODE_SECTION(UNMI_ISR, ".unmi_rom_isr") //comment this line for creating a custom WDT UNMI ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = UNMI_VECTOR
__interrupt void UNMI_ISR(void)
{
}

//#pragma CODE_SECTION(SysNMI_ISR, ".fram_driver_code")   //comment this line for using ROM's SYSNMI ISR, uncomment next one
#pragma CODE_SECTION(SysNMI_ISR, ".sysnmi_rom_isr") //comment this line for creating a custom WDT SYSNMI ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = SYSNMI_VECTOR
__interrupt void SysNMI_ISR(void)
{
}

#pragma RETAIN (Reset_ISR);
//#pragma CODE_SECTION(Reset_ISR, ".fram_driver_code")   //comment this line for using ROM's RESET ISR, uncomment next one
#pragma CODE_SECTION(Reset_ISR, ".reset_rom_isr") //comment this line for creating a custom WDT RESET ISR that will exist in FRAM, bypassing ROM's, uncomment previous
#pragma vector = RESET_VECTOR
extern __interrupt void Reset_ISR(void)
{
 }