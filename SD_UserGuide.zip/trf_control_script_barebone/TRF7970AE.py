# Barebone script to control the TRF7970EVM using custom commands
# Written by Team Valvano

import time
import serial

# full commands strings
# To initialize the communication, the script must send four initialization string
init1 = b'010A0003041001210000'			# Register write request
init2 = b'010C00030410002101020000'		# Register write request
init3 = b'0109000304F0000000'			# Automatic gain control toggle
init4 = b'0109000304F1FF0000'			# AM PM toggle
command = b'010C0003041802AA07020000'	# full custom command string

usb = serial.Serial('/dev/ttyUSB0', 115200) # open communication through USB port, set baudrate to 115200

usb.write(init1)
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
print(data)

usb.write(init2)
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
print(data)

usb.write(init3)
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
print(data)

usb.write(init4)
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
print(data)

usb.write(command)
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
print(data)

usb.write(b'00F')	# done command. Without this, the trf board needs to reset everytime it sends commands
time.sleep(.5)
data_size = usb.inWaiting()
data = usb.read(data_size)
usb.close()
